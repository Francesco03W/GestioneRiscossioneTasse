﻿namespace sceriffo0
{
    partial class Tasse1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelLogIn = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.srittaPassword = new System.Windows.Forms.Label();
            this.bottoneAccedi = new System.Windows.Forms.Button();
            this.ScrittaLogIn = new System.Windows.Forms.Label();
            this.PannelloAltoSX = new System.Windows.Forms.Panel();
            this.pannelRegistrazione = new System.Windows.Forms.Panel();
            this.bottoneInvioRegistrazione = new System.Windows.Forms.Button();
            this.contenitorePasswordInserita = new System.Windows.Forms.TextBox();
            this.scrittaIstruzioniPassword = new System.Windows.Forms.Label();
            this.scrittaRegistrazione = new System.Windows.Forms.Label();
            this.PannelloAltoDX = new System.Windows.Forms.Panel();
            this.PannelloBassoSX = new System.Windows.Forms.Panel();
            this.PannelloBassoDX = new System.Windows.Forms.Panel();
            this.panelLogIn.SuspendLayout();
            this.pannelRegistrazione.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLogIn
            // 
            this.panelLogIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLogIn.Controls.Add(this.textBox1);
            this.panelLogIn.Controls.Add(this.srittaPassword);
            this.panelLogIn.Controls.Add(this.bottoneAccedi);
            this.panelLogIn.Controls.Add(this.ScrittaLogIn);
            this.panelLogIn.Location = new System.Drawing.Point(628, 226);
            this.panelLogIn.Margin = new System.Windows.Forms.Padding(4);
            this.panelLogIn.Name = "panelLogIn";
            this.panelLogIn.Size = new System.Drawing.Size(441, 253);
            this.panelLogIn.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(68, 137);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(297, 22);
            this.textBox1.TabIndex = 3;
            // 
            // srittaPassword
            // 
            this.srittaPassword.AutoSize = true;
            this.srittaPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.srittaPassword.Location = new System.Drawing.Point(108, 103);
            this.srittaPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.srittaPassword.Name = "srittaPassword";
            this.srittaPassword.Size = new System.Drawing.Size(207, 29);
            this.srittaPassword.TabIndex = 2;
            this.srittaPassword.Text = "Inserire Password";
            // 
            // bottoneAccedi
            // 
            this.bottoneAccedi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bottoneAccedi.Location = new System.Drawing.Point(160, 192);
            this.bottoneAccedi.Margin = new System.Windows.Forms.Padding(4);
            this.bottoneAccedi.Name = "bottoneAccedi";
            this.bottoneAccedi.Size = new System.Drawing.Size(101, 33);
            this.bottoneAccedi.TabIndex = 1;
            this.bottoneAccedi.Text = "Accedi";
            this.bottoneAccedi.UseVisualStyleBackColor = true;
            this.bottoneAccedi.Click += new System.EventHandler(this.bottoneAccedi_Click);
            // 
            // ScrittaLogIn
            // 
            this.ScrittaLogIn.AutoSize = true;
            this.ScrittaLogIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.ScrittaLogIn.Location = new System.Drawing.Point(158, 34);
            this.ScrittaLogIn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ScrittaLogIn.Name = "ScrittaLogIn";
            this.ScrittaLogIn.Size = new System.Drawing.Size(103, 39);
            this.ScrittaLogIn.TabIndex = 0;
            this.ScrittaLogIn.Text = "LogIn";
            // 
            // PannelloAltoSX
            // 
            this.PannelloAltoSX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PannelloAltoSX.Location = new System.Drawing.Point(13, 13);
            this.PannelloAltoSX.Margin = new System.Windows.Forms.Padding(4);
            this.PannelloAltoSX.Name = "PannelloAltoSX";
            this.PannelloAltoSX.Size = new System.Drawing.Size(828, 407);
            this.PannelloAltoSX.TabIndex = 1;
            // 
            // pannelRegistrazione
            // 
            this.pannelRegistrazione.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pannelRegistrazione.Controls.Add(this.bottoneInvioRegistrazione);
            this.pannelRegistrazione.Controls.Add(this.contenitorePasswordInserita);
            this.pannelRegistrazione.Controls.Add(this.scrittaIstruzioniPassword);
            this.pannelRegistrazione.Controls.Add(this.scrittaRegistrazione);
            this.pannelRegistrazione.Location = new System.Drawing.Point(628, 74);
            this.pannelRegistrazione.Name = "pannelRegistrazione";
            this.pannelRegistrazione.Size = new System.Drawing.Size(441, 253);
            this.pannelRegistrazione.TabIndex = 4;
            // 
            // bottoneInvioRegistrazione
            // 
            this.bottoneInvioRegistrazione.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.bottoneInvioRegistrazione.Location = new System.Drawing.Point(154, 186);
            this.bottoneInvioRegistrazione.Name = "bottoneInvioRegistrazione";
            this.bottoneInvioRegistrazione.Size = new System.Drawing.Size(125, 39);
            this.bottoneInvioRegistrazione.TabIndex = 3;
            this.bottoneInvioRegistrazione.Text = "Registrati";
            this.bottoneInvioRegistrazione.UseVisualStyleBackColor = true;
            this.bottoneInvioRegistrazione.Click += new System.EventHandler(this.BottoneInvioRegistrazione_Click);
            // 
            // contenitorePasswordInserita
            // 
            this.contenitorePasswordInserita.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.contenitorePasswordInserita.Location = new System.Drawing.Point(33, 134);
            this.contenitorePasswordInserita.Name = "contenitorePasswordInserita";
            this.contenitorePasswordInserita.Size = new System.Drawing.Size(377, 30);
            this.contenitorePasswordInserita.TabIndex = 2;
            // 
            // scrittaIstruzioniPassword
            // 
            this.scrittaIstruzioniPassword.AutoSize = true;
            this.scrittaIstruzioniPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.scrittaIstruzioniPassword.Location = new System.Drawing.Point(28, 57);
            this.scrittaIstruzioniPassword.Name = "scrittaIstruzioniPassword";
            this.scrittaIstruzioniPassword.Size = new System.Drawing.Size(382, 50);
            this.scrittaIstruzioniPassword.TabIndex = 1;
            this.scrittaIstruzioniPassword.Text = "Inserire una password di almeno 8 caratteri\r\nMassimo 16 caratteri\r\n";
            // 
            // scrittaRegistrazione
            // 
            this.scrittaRegistrazione.AutoSize = true;
            this.scrittaRegistrazione.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.scrittaRegistrazione.Location = new System.Drawing.Point(127, 17);
            this.scrittaRegistrazione.Name = "scrittaRegistrazione";
            this.scrittaRegistrazione.Size = new System.Drawing.Size(188, 31);
            this.scrittaRegistrazione.TabIndex = 0;
            this.scrittaRegistrazione.Text = "Registrazione ";
            // 
            // PannelloAltoDX
            // 
            this.PannelloAltoDX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PannelloAltoDX.Location = new System.Drawing.Point(849, 13);
            this.PannelloAltoDX.Margin = new System.Windows.Forms.Padding(4);
            this.PannelloAltoDX.Name = "PannelloAltoDX";
            this.PannelloAltoDX.Size = new System.Drawing.Size(823, 407);
            this.PannelloAltoDX.TabIndex = 2;
            // 
            // PannelloBassoSX
            // 
            this.PannelloBassoSX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PannelloBassoSX.Location = new System.Drawing.Point(13, 428);
            this.PannelloBassoSX.Margin = new System.Windows.Forms.Padding(4);
            this.PannelloBassoSX.Name = "PannelloBassoSX";
            this.PannelloBassoSX.Size = new System.Drawing.Size(828, 397);
            this.PannelloBassoSX.TabIndex = 3;
            // 
            // PannelloBassoDX
            // 
            this.PannelloBassoDX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PannelloBassoDX.Location = new System.Drawing.Point(849, 428);
            this.PannelloBassoDX.Margin = new System.Windows.Forms.Padding(4);
            this.PannelloBassoDX.Name = "PannelloBassoDX";
            this.PannelloBassoDX.Size = new System.Drawing.Size(823, 397);
            this.PannelloBassoDX.TabIndex = 4;
            // 
            // Tasse1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1685, 838);
            this.Controls.Add(this.PannelloAltoSX);
            this.Controls.Add(this.PannelloBassoSX);
            this.Controls.Add(this.PannelloBassoDX);
            this.Controls.Add(this.PannelloAltoDX);
            this.Controls.Add(this.panelLogIn);
            this.Controls.Add(this.pannelRegistrazione);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Tasse1";
            this.Text = "Sceriffo ";
            this.Load += new System.EventHandler(this.Tasse1_Load);
            this.panelLogIn.ResumeLayout(false);
            this.panelLogIn.PerformLayout();
            this.pannelRegistrazione.ResumeLayout(false);
            this.pannelRegistrazione.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLogIn;
        private System.Windows.Forms.Label ScrittaLogIn;
        private System.Windows.Forms.Button bottoneAccedi;
        private System.Windows.Forms.Label srittaPassword;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel PannelloAltoSX;
        private System.Windows.Forms.Panel PannelloAltoDX;
        private System.Windows.Forms.Panel PannelloBassoSX;
        private System.Windows.Forms.Panel PannelloBassoDX;
        private System.Windows.Forms.Panel pannelRegistrazione;
        private System.Windows.Forms.Button bottoneInvioRegistrazione;
        private System.Windows.Forms.TextBox contenitorePasswordInserita;
        private System.Windows.Forms.Label scrittaIstruzioniPassword;
        private System.Windows.Forms.Label scrittaRegistrazione;
    }
}

